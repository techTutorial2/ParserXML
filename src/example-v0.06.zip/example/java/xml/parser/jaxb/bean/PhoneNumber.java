package example.java.xml.parser.jaxb.bean;

public class PhoneNumber {
	private String foo;
	private String bar;

	public String getType() {
		return foo;
	}

	public void setType(String type) {
		this.foo = type;
	}

	public String getNumber() {
		return bar;
	}

	public void setNumber(String number) {
		this.bar = number;
	}
}


package example.java.xml.parser.jaxb.main;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
//import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import example.java.xml.parser.jaxb.bean.Country;

//jaxb marshaling functionalities when managing complex classes, in this case java.time.LocalDate
public class DateAdapterMarshalJAXBComplexClass {

	public static void main(String[] args) throws ParseException {
		try {

			// init very simple data to marshal
			Country country = new Country();
			country.setName("Spain");
			country.setCapital("Madrid");
			country.setContinent("Europe");

			//country.setFoundation(LocalDate.of(1469, 10, 19));
			country.setFoundation(new SimpleDateFormat("yyyy, MM, dd").parse("1469, 10, 20"));
			//country.setFoundation(Calendar.getInstance().getTime());

			// init jaxb marshaler
			JAXBContext jaxbContext = JAXBContext.newInstance(Country.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			// set this flag to true to format the output
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

			// marshaling of java objects in xml (output to file and standard
			// output)
			jaxbMarshaller.marshal(country, new File(
					"src/example/java/xml/parser/jaxb/xml/country_adapter.xml"));
			jaxbMarshaller.marshal(country, System.out);

		} catch (JAXBException e) {
			e.printStackTrace();
		}

	}
}

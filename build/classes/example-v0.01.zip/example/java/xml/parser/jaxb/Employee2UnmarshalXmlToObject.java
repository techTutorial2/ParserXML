package example.java.xml.parser.jaxb;

import java.io.File;  
import javax.xml.bind.JAXBContext;  
import javax.xml.bind.JAXBException;  
import javax.xml.bind.Unmarshaller;  
  
public class Employee2UnmarshalXmlToObject {  
public static void main(String[] args) {  
     try {    
            File file = new File("F:/workspaceEasyStepSync/SpringSample/src/example/java/xml/parser/jaxb/employee2-unmarshal.xml");    
            JAXBContext jaxbContext = JAXBContext.newInstance(Employee2.class);    
         
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();    
            Employee2 e=(Employee2) jaxbUnmarshaller.unmarshal(file);    
            System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());  
              
          } catch (JAXBException e) {e.printStackTrace(); }    
         
}  
}  
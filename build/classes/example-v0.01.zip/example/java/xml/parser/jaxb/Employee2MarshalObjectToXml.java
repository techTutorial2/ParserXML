package example.java.xml.parser.jaxb;

import java.io.FileOutputStream;  
  
import javax.xml.bind.JAXBContext;  
import javax.xml.bind.Marshaller;  
  
  
public class Employee2MarshalObjectToXml {  
public static void main(String[] args) throws Exception{  
    JAXBContext contextObj = JAXBContext.newInstance(Employee2.class);  
  
    Marshaller marshallerObj = contextObj.createMarshaller();  
    marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);  
  
    Employee2 emp1=new Employee2(1,"Vimal Jaiswal",50000);  
      
    marshallerObj.marshal(emp1, new FileOutputStream("F:/workspaceEasyStepSync/SpringSample/src/example/java/xml/parser/jaxb/employee2-marshal.xml"));  
       
}  
}  